import makeBuiltin.MakeCircleHyperEdge;
import makeBuiltin.MakeOrderedHyperEdge;
import makeBuiltin.MakeStarHyperEdge;
import org.apache.jena.graph.Triple;
import org.apache.jena.ontology.*;

import org.apache.jena.query.*;
import org.apache.jena.rdf.model.Model;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.rdf.model.StmtIterator;
import org.apache.jena.reasoner.InfGraph;
import org.apache.jena.reasoner.rulesys.*;
import org.apache.jena.riot.RDFDataMgr;
import org.apache.jena.util.PrintUtil;
import utils.Constant;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Iterator;
import java.util.List;

public class HyperGraphReason {
    private static String finhg = "http://www.semanticweb.org/2021/4/27/fin-temporal-hypergraph#";
    public static void main(String[] args) {
        String ontModelPath = "C:\\Users\\zheng\\Desktop\\金融时序超图\\文件和代码\\fin-temporal-hypergraph.owl";
//        String dataPath = "F:\\python\\project\\3-Fin\\graph\\data.nt";
        String rulesPath = "F:\\python\\project\\3-Fin\\graph\\myRules.rules";
        // 注入本体
        OntModel ontModel = ModelFactory.createOntologyModel(OntModelSpec.OWL_MEM);
        try {
            ontModel.read(new FileInputStream(ontModelPath),null,"TTL");
        } catch (FileNotFoundException e) {
            System.out.println("文件加载异常");
            e.printStackTrace();
        }
        // 注入数据
//        RDFDataMgr.read(ontModel, dataPath);
        // 有序链
        //orderedChainHyperEdge(ontModel);
        // 设置前缀输出原始数据
        PrintUtil.registerPrefix("finhg", Constant.finhg);
        StmtIterator i = ontModel.listStatements();
        while (i.hasNext()){
            System.out.println("-" + PrintUtil.print(i.nextStatement()));
        }
        // 星型向内
        long start = System.currentTimeMillis();
        String queryHasParentCompany =  "prefix finhg:<http://www.semanticweb.org/2021/4/27/fin-hypergraph#>\n" +
                "prefix rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#>\n"+
                "select distinct ?s ?o\n" +
                "where { \n" +
                "       ?s finhg:hasParentCompany ?o." +
                "}";
        String queryCircleShareholding =
                "prefix finhg:<http://www.semanticweb.org/2021/4/27/fin-hypergraph#>\n" +
                        "select distinct ?s ?p ?o\n" +
                        "where { \n" +
                        "       ?s finhg:circleShareholding ?o . \n" +
                        "?s ?p ?o. \n" +
                        "}";
        String queryAsDirectorOf =
                "prefix finhg:<http://www.semanticweb.org/2021/4/27/fin-hypergraph#>\n" +
                        "select  ?o\n" +
                        "where { \n" +
                        "       finhg:田丽 finhg:asDirectorOf ?o . \n" +
                        "}";
        String queryBondTogetherGuarantee =
                "prefix finhg:<http://www.semanticweb.org/2021/4/27/fin-hypergraph#>\n" +
                        "select ?s \n" +
                        "where { \n" +
                        "       ?s finhg:bondTogetherGuarantee finhg:Bond128118 . \n" +
                        "}";
        Query query=QueryFactory.create(queryBondTogetherGuarantee);
        QueryExecution qe = QueryExecutionFactory.create(query,ontModel);
        ResultSet results = qe.execSelect();
        ResultSetFormatter.out(System.out, results,query);
        long end = System.currentTimeMillis();
        System.out.println(end - start);
        qe.close();

        // 注册元语
        BuiltinRegistry.theRegistry.register(new MakeStarHyperEdge());
        BuiltinRegistry.theRegistry.register(new MakeCircleHyperEdge());
        BuiltinRegistry.theRegistry.register(new MakeOrderedHyperEdge());

        List<Rule> rules = Rule.rulesFromURL(rulesPath);
        // 创建规则推理机
        GenericRuleReasoner reasoner = (GenericRuleReasoner) GenericRuleReasonerFactory.theInstance().create(null);
        reasoner.setOWLTranslation(true);
        reasoner.setRules(rules);
        reasoner.setMode(GenericRuleReasoner.HYBRID);
        // 绑定本体和数据图Model,生成新Model即新图,输出
        InfGraph infGraph = reasoner.bind(ontModel.getGraph());
        infGraph.setDerivationLogging(true);
        System.out.println("推理后.....");
        // 测试输出
        // 星型向外
//        Resource resource = ResourceFactory.createResource(finhg + "DisDirectorOf");
        Iterator<Triple> tripleIterator = infGraph.find(null,null,null);
        while(tripleIterator.hasNext()){
            System.out.println(" - " + PrintUtil.print(tripleIterator.next()));
        }
        // 将推理图转化为ontModel
        Model ontModel1 = ModelFactory.createModelForGraph(infGraph);
        // 星型向内
        long start1 = System.currentTimeMillis();
        String queryCount =
                        "select count(?s)\n" +
                        "where { \n" +
                        "       ?s ?p ?o . \n" +
                        "}";
        // 查询有序超边
        String queryOrderedChainHyperEdge =  "prefix finhg:<http://www.semanticweb.org/2021/4/27/fin-hypergraph#>\n" +
                "prefix rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#>\n"+
                "select distinct ?s ?p ?o\n" +
                "where { \n" +
                "       ?s rdf:type finhg:OrderedHyperEdge . \n" +
                "       ?s ?p ?o . \n" +
                "}";

        String queryAsDirectorOf1 =
                "prefix finhg:<http://www.semanticweb.org/2021/4/27/fin-hypergraph#>\n" +
                        "prefix rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#>\n" +
                        "select ?hyperEdge ?p ?o\n" +
                        "where {\n" +
                        "?hyperEdge rdf:type finhg:UnorderedHyperEdge.\n" +
                        "?hyperEdge finhg:hasCenter finhg:田丽 .\n" +
                        "?hyperEdge ?p ?o.\n" +
                        "}";
        String querybondTogetherGuarantee1 =
                "prefix finhg:<http://www.semanticweb.org/2021/4/27/fin-temporal-hypergraph#>\n" +
                        "prefix rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#>\n" +
                        "select ?hyperEdge ?p ?o\n" +
                        "where {\n" +
                        "?hyperEdge rdf:type finhg:UnorderedHyperEdge.\n" +
                        "?hyperEdge finhg:hasCenter finhg:Bond128118 .\n" +
                        "?hyperEdge ?p ?o.\n" +
                        "}";
        Query query1= QueryFactory.create(queryCount);
        QueryExecution qe1 = QueryExecutionFactory.create(query1,ontModel1);
        ResultSet results1 = qe1.execSelect();
        ResultSetFormatter.out(System.out, results1,query1);
        long end1 = System.currentTimeMillis();
        System.out.println(end1 - start1);
        qe1.close();
    }

    public static OntModel orderedChainHyperEdge(OntModel ontModel){
        // 有序链--母公司
        OntClass company = ontModel.getOntClass(finhg + "Company");
        Individual A = company.createIndividual(finhg + "A");
        Individual B = company.createIndividual(finhg + "B");
        Individual C = company.createIndividual(finhg + "C");
        ObjectProperty hasParentCompany = ontModel.getObjectProperty(finhg + "hasParentCompany");
        ontModel.add(A,hasParentCompany,B);
        ontModel.add(B,hasParentCompany,C);
        return ontModel;
    }

}
