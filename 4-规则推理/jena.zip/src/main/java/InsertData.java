import org.apache.jena.ontology.*;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.rdf.model.Property;
import org.apache.jena.rdf.model.Resource;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class InsertData {
    // 星型向内- 共同担保
    /*
    public static void main(String[] args) {
        String dataPath = "F:\\python\\project\\3-Fin\\data\\债券担保.xlsx";

        // 初始化graph
        OntModel ontModel = ModelFactory.createOntologyModel(OntModelSpec.OWL_MEM);
        String finhg = "http://www.semanticweb.org/2021/4/27/fin-hypergraph#";
        ontModel.setNsPrefix("finhg",finhg);

        Property guaranteeBond = ontModel.createProperty(finhg + "bondTogetherGuarantee");
        // 读文件创建图谱
        Workbook workbook = null;
        try {
            FileInputStream fileInputStream = new FileInputStream(dataPath);
            workbook = new XSSFWorkbook(fileInputStream);
        } catch (FileNotFoundException e) {
            System.out.println("导入Excel文档出错");
            e.printStackTrace();
        } catch (IOException e){
            e.printStackTrace();
        }
        Sheet sheet = workbook.getSheet("Sheet1");
        int totalRowNum = sheet.getLastRowNum()+1; // sheet.getLastRowNum = 最后一行序号-1

        for(int i=1;i<totalRowNum;i++){  // i=表格行号
            Row row = sheet.getRow(i);
            String[] guarantors = row.getCell(0).toString().split(" "); // 列从0开始

            int bondId = (int)row.getCell(3).getNumericCellValue();
            Resource bond = ontModel.createResource(finhg + "Bond" + bondId);
            if(guarantors.length > 1){
                for(String guarantor:guarantors){
                    Resource  guarantorResource= ontModel.createResource(finhg + guarantor);
                    ontModel.add(guarantorResource, guaranteeBond, bond);
                }
            }
        }

        // 存储
        String savePath = "F:\\python\\project\\3-Fin\\graph\\data.nt";
        try {
            FileOutputStream fileOs = new FileOutputStream(savePath);
            ontModel.write(fileOs, "N-TRIPLE");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
    */

    public static void main(String[] args) {
        // 星型向外-董事
        String data2Path = "F:\\python\\project\\3-Fin\\data\\董事.xlsx";

        // 初始化graph
        OntModel ontModel = ModelFactory.createOntologyModel(OntModelSpec.OWL_MEM);
        String finhg = "http://www.semanticweb.org/2021/4/27/fin-hypergraph#";
        ontModel.setNsPrefix("finhg",finhg);

        Property servingDirector = ontModel.createProperty(finhg + "asDirectorOf");
        // 读文件创建图谱
        Workbook workbook = null;
        try {
            FileInputStream fileInputStream = new FileInputStream(data2Path);
            workbook = new XSSFWorkbook(fileInputStream);
        } catch (FileNotFoundException e) {
            System.out.println("导入Excel文档出错");
            e.printStackTrace();
        } catch (IOException e){
            e.printStackTrace();
        }
        Sheet sheet = workbook.getSheet("Sheet1");
        int totalRowNum = sheet.getLastRowNum()+1; // sheet.getLastRowNum = 最后一行序号-1

        for(int i=1;i<totalRowNum;i++){  // i=表格行号
            Row row = sheet.getRow(i);
            String personName = row.getCell(0).toString(); // 列从0开始
            Resource person = ontModel.createResource(finhg + personName);
            int num = 1;
            while(row.getCell(num) != null){
                String companyName = row.getCell(num).toString();
                Resource company = ontModel.createResource(finhg + companyName);
                ontModel.add(person, servingDirector, company);
                num++;
            }

            }
        // 存储
        String savePath = "F:\\python\\project\\3-Fin\\graph\\data.nt";
        try {
            FileOutputStream fileOs = new FileOutputStream(savePath,true);
            ontModel.write(fileOs, "N-TRIPLE");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }


}
