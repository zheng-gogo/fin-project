import entity.Business;
import entity.Company;
import entity.GeneralDurationDescription;
import entity.Person;
import org.apache.jena.ontology.*;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.rdf.model.Resource;
import org.apache.jena.reasoner.Reasoner;
import org.apache.jena.reasoner.rulesys.GenericRuleReasoner;
import org.apache.jena.reasoner.rulesys.Rule;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import utils.ModelingUtil;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import static utils.FillDataUtil.setDataPropertyValue;
import static utils.XlsxUtil.getCellContentByIndex;

public class createCompany {
    private static String dataFileName = "F:\\python\\project\\3-Fin\\data\\2 githubFin-data\\结构化-工商数据集样本10K.xlsx";
    private static String savePath = "F:\\python\\project\\3-Fin\\data\\2 githubFin-data\\company.owl";
    public static void main(String[] args) {
        OntModel ontModel = ModelFactory.createOntologyModel(OntModelSpec.OWL_MEM);
        // 为整个图添加前缀
        String name_space = "http://www.semanticweb.org/zheng/ontologies/Fin/202103239#";
        ontModel.setNsPrefix("fin", name_space);
        String timePrefix = "http://www.w3.org/2006/time#";
        ontModel.setNsPrefix("time",timePrefix);
        // -----------  Class --------------
        OntClass companyClass = ontModel.createClass(name_space + "Company");
        OntClass personClass = ontModel.createClass(name_space  + "Person");
        OntClass businessClass = ontModel.createClass(name_space + "Business");

        // ----------- DataProperty ------------
        // Company-DataProperty
        Company company = new Company();
        ModelingUtil.setDataProperty(ontModel, companyClass, company, name_space);
        // Person-DataProperty
        Person person = new Person();
        ModelingUtil.setDataProperty(ontModel, personClass, person, name_space);
        // Business-DataProperty
        Business business = new Business();
        ModelingUtil.setDataProperty(ontModel, businessClass, business, name_space);

        // ------------ ObjectProperty -------------
        // Company-ObjectProperty:hasLegalPerson
         ObjectProperty hasLegalPerson = ontModel.createObjectProperty(name_space + "hasLogalPerson");
         hasLegalPerson.addDomain(companyClass);
         hasLegalPerson.addRange(personClass);
        // Company-ObjectProperty:hasBusiness
         ObjectProperty hasBusiness = ontModel.createObjectProperty(name_space + "hasBusiness");
         hasBusiness.addDomain(companyClass);
         hasBusiness.addRange(businessClass);

        // ------------ 填充实例  ----------
        // 读入Excel
        Workbook workbook = null;
        try {
            FileInputStream fileInputStream = new FileInputStream(dataFileName);
            workbook = new XSSFWorkbook(fileInputStream);
        } catch (FileNotFoundException e) {
            System.out.println("导入Excel文档出错");
            e.printStackTrace();
        } catch (IOException e){
            e.printStackTrace();
        }
        Sheet sheet = workbook.getSheet("Sheet1");
        int totalRowNum = sheet.getLastRowNum();
        for(int i=1;i<2;i++){
            Row row = sheet.getRow(i);
            // ----------setCompany-------------
            String companyName = getCellContentByIndex(row,1);
            Individual companyIndividual = companyClass.createIndividual(name_space + companyName);
            String companyAbbrevation = getCellContentByIndex(row,0);
            String companyIntroduction = getCellContentByIndex(row,2);
            String companyUnifiedCreditCode = getCellContentByIndex(row,9);
            String companyWebURL = getCellContentByIndex(row,10);
            Company comanyItem = new Company(companyAbbrevation,companyName,companyIntroduction,
                                                    companyUnifiedCreditCode,companyWebURL);
            setDataPropertyValue(comanyItem,ontModel,name_space,companyIndividual);
            // -----------setBusiness------------
            String businessName = getCellContentByIndex(row,3);
            Individual businessIndividual = businessClass.createIndividual(name_space + businessName + "工商");
            String bisinessId = getCellContentByIndex(row,5);
            Business businessItem = new Business(bisinessId,businessName);
            setDataPropertyValue(businessItem,ontModel,name_space,businessIndividual);
            // -----------setPerson--------------
            String personName = getCellContentByIndex(row,7);
            Individual personIndividual = personClass.createIndividual(name_space + personName);
            Person personItem = new Person(personName);
            setDataPropertyValue(personItem,ontModel,name_space,personIndividual);
            // ---------- setTime--------------------
            // 可以指代三元组中各个节点/类型/属性
//            String estabilishTime = getCellContentByIndex(row,6);
//            Resource resource = ontModel.createOntResource(timePrefix+"GeneralDurationDescription");
//            Individual establishTimeIndividual = ontModel.createIndividual(name_space + estabilishTime,resource);
//            String[] dateInfo = estabilishTime.split("-");
//            GeneralDurationDescription generalDurationDescription = new GeneralDurationDescription(dateInfo[0],dateInfo[1],dateInfo[2]);
//            setDataPropertyValue(generalDurationDescription,ontModel,timePrefix,establishTimeIndividual);

            // ----------setObjectProperty---------
            companyIndividual.addProperty(hasBusiness,businessIndividual);
            companyIndividual.addProperty(hasLegalPerson,personIndividual);
        }
        try {
            FileOutputStream fileOs = new FileOutputStream(savePath);
            ontModel.write(fileOs, "RDF/XML-ABBREV");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
//        ontModel.write(System.out, "RDF/XML-ABBREV");
//        ontModel.write(System.out, "N-TRIPLE");
        OntModel ontModel1 = ModelFactory.createOntologyModel(OntModelSpec.OWL_MEM);
        ontModel1.read(savePath);
        ontModel.write(System.out, "N-TRIPLE");
    }







}
