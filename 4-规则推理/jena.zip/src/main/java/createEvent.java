import org.apache.jena.graph.Triple;
import org.apache.jena.ontology.OntClass;
import org.apache.jena.ontology.OntModel;
import org.apache.jena.ontology.OntModelSpec;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.reasoner.InfGraph;
import org.apache.jena.reasoner.rulesys.GenericRuleReasoner;
import org.apache.jena.reasoner.rulesys.GenericRuleReasonerFactory;
import org.apache.jena.reasoner.rulesys.Rule;
import org.apache.jena.util.PrintUtil;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Iterator;
import java.util.List;

public class createEvent {
    public static void main(String[] args) {

        String ontModelPath = "F:\\python\\project\\3-Fin\\graph\\20210412test.owl";
        String rulesPath = "F:\\python\\project\\3-Fin\\graph\\myRules.rules";
        OntModel ontModel = ModelFactory.createOntologyModel(OntModelSpec.OWL_MEM);
        String rdf = "http://www.w3.org/1999/02/22-rdf-syntax-ns#";
        String fin = "http://www.semanticweb.org/zheng/fin-event#";
        String time = "http://www.w3.org/2006/time#";
        ontModel.setNsPrefix("",fin);
        ontModel.setNsPrefix("rdf",rdf);
        ontModel.setNsPrefix("time",time);
        try {
            ontModel.read(new FileInputStream(ontModelPath),null,"TTL");
        } catch (FileNotFoundException e) {
            System.out.println("文件加载异常");
            e.printStackTrace();
        }
        List<Rule> rules =  Rule.rulesFromURL(rulesPath);
        GenericRuleReasoner reasoner = (GenericRuleReasoner) GenericRuleReasonerFactory.theInstance().create(null);
        reasoner.setRules(rules);
        reasoner.setMode(GenericRuleReasoner.HYBRID);
        InfGraph infGraph = reasoner.bind(ontModel.getGraph());
        infGraph.setDerivationLogging(true);
        System.out.println("推理后....");
        Iterator<Triple> tripleIterator = infGraph.find(null,null,null);
        while (tripleIterator.hasNext()){
            System.out.println(" - "+ PrintUtil.print(tripleIterator.next()));
        }
        ontModel.write(System.out, "N-TRIPLE");


    }
}
