package entity;

import lombok.Data;

@Data
public class Business {
    private String businessId;
    private String businessName;

    public Business() {
    }

    public Business(String businessId, String businessName) {
        this.businessId = businessId;
        this.businessName = businessName;
    }
}
