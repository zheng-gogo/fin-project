package entity;

import lombok.Data;

@Data
public class Company {
    private String companyAbbrevation;
    private String companyName;
    private String companyIntroduction;
    private String companyUnifiedCreditCode;
    private String companyWebURL;

    public Company() {
    }

    public Company(String companyAbbrevation, String companyName, String companyIntroduction, String companyUnifiedCreditCode, String companyWebURL) {
        this.companyAbbrevation = companyAbbrevation;
        this.companyName = companyName;
        this.companyIntroduction = companyIntroduction;
        this.companyUnifiedCreditCode = companyUnifiedCreditCode;
        this.companyWebURL = companyWebURL;
    }




}
