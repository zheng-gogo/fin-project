package entity;

import lombok.Data;

@Data
public class GeneralDurationDescription {
    String years;
    String months;
    String days;

    public GeneralDurationDescription() {
    }

    public GeneralDurationDescription(String years, String months, String days) {
        this.years = years;
        this.months = months;
        this.days = days;
    }
}
