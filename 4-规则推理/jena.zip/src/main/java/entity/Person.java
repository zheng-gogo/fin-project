package entity;

import lombok.Data;

@Data
public class Person {
    private String personName;

    public Person() {
    }

    public Person(String personName) {
        this.personName = personName;
    }
}
