package makeBuiltin;

import org.apache.jena.graph.Node;
import org.apache.jena.graph.NodeFactory;
import org.apache.jena.graph.Triple;
import org.apache.jena.reasoner.rulesys.RuleContext;
import org.apache.jena.reasoner.rulesys.builtins.BaseBuiltin;
import utils.Constant;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class MakeCircleHyperEdge extends BaseBuiltin {

    public String getName() {
        return "makeCircleHyperEdge";
    }

    @Override
    public boolean bodyCall(Node[] args, int length, RuleContext context) {
        // 命名新节点
        Node node = args[0];
        List<String> name =new ArrayList<String>();
        name.add(args[0].getLocalName());
        do{
                Iterator<Triple> tripleIterator1 = context.find(node,args[1],null);
                node = tripleIterator1.next().getObject();
                name.add(node.getLocalName());
            }while(node!=args[0]);
        String nodeNames =  args[0].getLocalName();
        name.remove(name.size()-1);
        for(int i = 1;i<name.size(); i++){
            nodeNames+= "-"+name.get(i);
        }
        // 检验是否已经存在此环
        // 此处可改为sparql模糊查询
        Node type = NodeFactory.createURI( Constant.rdfprefix + "type");
        Node orderedHyperEdge = NodeFactory.createURI(Constant.finhg + "OrderedHyperEdge");
        Iterator<Triple> tripleIterator1 = context.find(null,type,orderedHyperEdge);
        while(tripleIterator1.hasNext()){
            Node temp = tripleIterator1.next().getSubject();
            String[] circleEdge = temp.getLocalName().split("-");
            // 比较关系
            if(!circleEdge[circleEdge.length-1].equals(args[1].getLocalName()))continue;
            // 找第一个头元素
            int index= -1;
            for(int i = 0;i<circleEdge.length-1;i++){
                    if(circleEdge[i].equals(args[0].getLocalName())){
                        index = i;
                        break;
                    }
            }

            int index2 = 0;
            if(index!=-1){
                for(int i = index;i<circleEdge.length-1;i++){
                    if(!circleEdge[i].equals(name.get(index2))) break;
                    else index2++;
                }
                for(int i = 0;i<index;i++){
                    if(!circleEdge[i].equals(name.get(index2))) break;
                    else index2++;
                }
            }
            if(!context.getEnv().bind(args[2],temp)) return false;
            return true;
        }
        nodeNames+= "-"+args[1].getLocalName();
        Node subject = NodeFactory.createURI(Constant.finhg + nodeNames);
        // 创建三元组
        for(int i = 0;i<name.size(); i++){
            Node predict = NodeFactory.createURI(Constant.rdfprefix + "_"+(i+1));
            Node object = NodeFactory.createURI(Constant.finhg + name.get(i));
            Triple triple = new Triple(subject,predict,object);
            System.out.println(triple.toString());
            context.add(triple);
        }
        if(!context.getEnv().bind(args[2],subject)) return false;
        return true;
    }
}
