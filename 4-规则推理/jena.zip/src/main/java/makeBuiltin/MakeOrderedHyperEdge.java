package makeBuiltin;

import org.apache.jena.graph.Node;
import org.apache.jena.graph.NodeFactory;
import org.apache.jena.graph.Triple;
import org.apache.jena.reasoner.rulesys.RuleContext;
import org.apache.jena.reasoner.rulesys.builtins.BaseBuiltin;
import utils.Constant;

import java.util.Iterator;

public class MakeOrderedHyperEdge extends BaseBuiltin {
    public String getName() {
        return "makeOrderedHyperEdge";
    }

    @Override
    public boolean bodyCall(Node[] args, int length, RuleContext context) {
        // firstNode
        Node object = args[0];
        String firstNodeName = object.getLocalName();
        String edgeName = args[1].getLocalName();
        String newNodeURI = Constant.finhg + firstNodeName+ "-" + edgeName;
        Node subject = NodeFactory.createURI(newNodeURI);
        Node predict = NodeFactory.createURI( Constant.rdfprefix + "first");
        Iterator<Triple> tripleIterator = context.find(subject,predict,object);
        if(tripleIterator.hasNext()){
            // hasCenter(subject,predict)
            if(!context.getEnv().bind(args[2], tripleIterator.next().getSubject())) return false;
        }else {
            if(!context.getEnv().bind(args[2],subject)) return false;
        }
        return true;
    }
}
