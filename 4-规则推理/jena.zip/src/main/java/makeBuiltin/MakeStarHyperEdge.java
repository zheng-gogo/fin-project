package makeBuiltin;

import org.apache.jena.graph.Node;
import org.apache.jena.graph.NodeFactory;

import org.apache.jena.graph.Triple;
import org.apache.jena.reasoner.rulesys.BackwardRuleInfGraphI;
import org.apache.jena.reasoner.rulesys.RuleContext;
import org.apache.jena.reasoner.rulesys.builtins.BaseBuiltin;
import org.apache.jena.reasoner.rulesys.builtins.MakeInstance;
import utils.Constant;

import java.util.Iterator;

public class MakeStarHyperEdge extends BaseBuiltin {
    public String getName() {
        return "makeStarHyperEdge";
    }

    @Override
    public boolean bodyCall(Node[] args, int length, RuleContext context) {
        // centerNode
        Node object = args[0];
        String centerNodeName = object.getLocalName();
        String edgeName = args[1].getLocalName();
        // newNodeURI = centerNodeName + EdgeComponentName
        String newNodeURI = Constant.finhg + centerNodeName +"-"+ edgeName;
        Node subject = NodeFactory.createURI(newNodeURI);
        Node predict = NodeFactory.createURI( Constant.finhg + "hasCenter");
        Iterator<Triple> tripleIterator = context.find(subject,predict,object);
        if(tripleIterator.hasNext()){
            // 已存在
            if(!context.getEnv().bind(args[2], tripleIterator.next().getSubject())) return false;
        }else {
            // 不存在，新建节点
           if(!context.getEnv().bind(args[2],subject)) return false;
        }

        return true;
    }

    @Override
    public void headAction(Node[] args, int length, RuleContext context) {
        super.headAction(args, length, context);
    }
}
