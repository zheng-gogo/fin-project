package utils;

public class Constant {
    public static String finhg = "http://www.semanticweb.org/2021/4/27/fin-temporal-hypergraph#";
    public static String rdfprefix = "http://www.w3.org/1999/02/22-rdf-syntax-ns#";
}
