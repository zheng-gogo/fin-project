package utils;

import org.apache.jena.ontology.DatatypeProperty;
import org.apache.jena.ontology.Individual;
import org.apache.jena.ontology.OntModel;

import java.lang.reflect.Field;

public class FillDataUtil {
    // 将对象中的属性值设置到对应的实体中
    public static void setDataPropertyValue(Object obj, OntModel ontModel, String name_space, Individual individual){
        Field[] fields = obj.getClass().getDeclaredFields();
        for(Field field:fields){
            field.setAccessible(true);
            try {
                String key = field.getName();
                if(field.get(obj) != null){
                    String value = field.get(obj).toString();
                    String uri = name_space + key;
                    DatatypeProperty datatypeProperty = ontModel.getDatatypeProperty(uri);
                    individual.addProperty(datatypeProperty,value);
                }
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
        }

    }
}
