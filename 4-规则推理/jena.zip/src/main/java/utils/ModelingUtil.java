package utils;

import org.apache.jena.ontology.DatatypeProperty;
import org.apache.jena.ontology.OntClass;
import org.apache.jena.ontology.OntModel;

import java.lang.reflect.Field;

public class ModelingUtil {
    // OntClass是知识图谱中的实例，Object是对应的java类，将java类的属性对应为数据属性DataProperty
    public static void setDataProperty(OntModel ontModel, OntClass ontClass, Object object, String name_space){
        Field[] fields = object.getClass().getDeclaredFields();
        for(Field field: fields){
            // field是属性名，fieldName是属性名称
            String fieldName = field.getName();
            DatatypeProperty dataPropertyItem = ontModel.createDatatypeProperty(name_space + fieldName);
            dataPropertyItem.addDomain(ontClass);
        }
    }
}
