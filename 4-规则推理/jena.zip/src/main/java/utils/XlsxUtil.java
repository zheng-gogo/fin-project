package utils;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

import static org.apache.poi.ss.usermodel.Row.MissingCellPolicy.RETURN_BLANK_AS_NULL;

public class XlsxUtil {
    public static String getCellContentByIndex(Row row, int index){
        Cell cell = row.getCell(index,RETURN_BLANK_AS_NULL);
        return cell==null?null:cell.getStringCellValue();
    }
}
